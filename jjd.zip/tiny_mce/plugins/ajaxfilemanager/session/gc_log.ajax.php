<?php die(); ?>
gc start at 10/Jun/2012 14:13:08
