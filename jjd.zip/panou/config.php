<?php
$versiune="0.8.1.2";
//setari locale
$server = "localhost";
$database = "jjd_db";
$db_user = "root";
$db_pass = "";
$tab_pagini = "trampz_pagini";
$tab_fisiere = "trampz_fisiere";
$tab_produse = "trampz_produse";
$tab_categorii = "trampz_categorii";
$xtable = "trampz_utilizator";		
$ftp_upload = "upload/";
$ftp_server = "***";
$ftp_user = "***";
$ftp_pass = "***";
?>