<section class="top-image">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h1><?php echo $word['aboutus_'.$lang];?></h1>
                <img src="assets/images/top-image.jpg" alt="">
                <div class="down-content">
                    <p><?php echo $row[$continut];?></p>
                    <div class="primary-button">
                        <a href="index.php">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>